
import bpy
import random
import math

# AI-GENERATED WATER FEATURE
# Type: pond
# Theme: modern
# Position: (14.6, 22.1)

def create_water_feature():
    """Create pond water feature"""
    water_objects = []
    
    if "pond" == "pond":
        water_objects = create_pond()
    elif "pond" == "fountain":
        water_objects = create_fountain()
    elif "pond" == "stream":
        water_objects = create_stream()
    elif "pond" == "oasis":
        water_objects = create_oasis()
    else:
        water_objects = create_generic_water()
    
    return water_objects

def create_pond():
    """Create a natural pond"""
    pond_objects = []
    
    # Main water body
    bpy.ops.mesh.primitive_cylinder_add(
        radius=4,
        depth=0.5,
        location=(14.62359758822056, 22.101406494437892, -0.25)
    )
    water = bpy.context.active_object
    water.name = f"AI_pond_water_1"
    pond_objects.append(water)
    
    # Pond edge/rim
    bpy.ops.mesh.primitive_torus_add(
        major_radius=4.2,
        minor_radius=0.3,
        location=(14.62359758822056, 22.101406494437892, 0)
    )
    rim = bpy.context.active_object
    rim.name = f"AI_pond_rim_1"
    pond_objects.append(rim)
    
    return pond_objects

def create_fountain():
    """Create an ornamental fountain"""
    fountain_objects = []
    
    # Fountain base
    bpy.ops.mesh.primitive_cylinder_add(
        radius=2,
        depth=0.5,
        location=(14.62359758822056, 22.101406494437892, 0.25)
    )
    base = bpy.context.active_object
    base.name = f"AI_fountain_base_1"
    fountain_objects.append(base)
    
    # Water basin
    bpy.ops.mesh.primitive_cylinder_add(
        radius=1.8,
        depth=0.3,
        location=(14.62359758822056, 22.101406494437892, 0.4)
    )
    basin = bpy.context.active_object
    basin.name = f"AI_fountain_basin_1"
    fountain_objects.append(basin)
    
    # Central spout
    bpy.ops.mesh.primitive_cylinder_add(
        radius=0.1,
        depth=2,
        location=(14.62359758822056, 22.101406494437892, 1.5)
    )
    spout = bpy.context.active_object
    spout.name = f"AI_fountain_spout_1"
    fountain_objects.append(spout)
    
    return fountain_objects

def create_stream():
    """Create a flowing stream"""
    stream_objects = []
    
    # Create stream bed as curved path
    stream_length = 15
    segments = 8
    
    for i in range(segments):
        segment_x = 14.62359758822056 + (i - segments/2) * 2
        segment_y = 22.101406494437892 + math.sin(i * 0.5) * 2  # Curved path
        
        bpy.ops.mesh.primitive_cube_add(
            size=1,
            location=(segment_x, segment_y, -0.1)
        )
        segment = bpy.context.active_object
        segment.scale = (1.5, 0.8, 0.2)
        bpy.ops.object.transform_apply(scale=True)
        segment.name = f"AI_stream_segment_{i}_1"
        stream_objects.append(segment)
    
    return stream_objects

def create_oasis():
    """Create a desert oasis"""
    oasis_objects = []
    
    # Central water pool
    bpy.ops.mesh.primitive_cylinder_add(
        radius=3,
        depth=0.4,
        location=(14.62359758822056, 22.101406494437892, -0.2)
    )
    water = bpy.context.active_object
    water.name = f"AI_oasis_water_1"
    oasis_objects.append(water)
    
    # Surrounding vegetation (palm trees)
    for i in range(random.randint(3, 6)):
        angle = i * (2 * math.pi / 6)
        palm_x = 14.62359758822056 + math.cos(angle) * 5
        palm_y = 22.101406494437892 + math.sin(angle) * 5
        
        # Palm trunk
        bpy.ops.mesh.primitive_cylinder_add(
            radius=0.2,
            depth=4,
            location=(palm_x, palm_y, 2)
        )
        trunk = bpy.context.active_object
        trunk.name = f"AI_palm_trunk_{i}_1"
        oasis_objects.append(trunk)
        
        # Palm fronds
        for j in range(6):
            frond_angle = j * (2 * math.pi / 6)
            frond_x = palm_x + math.cos(frond_angle) * 2
            frond_y = palm_y + math.sin(frond_angle) * 2
            
            bpy.ops.mesh.primitive_cube_add(
                size=1,
                location=(frond_x, frond_y, 4.5)
            )
            frond = bpy.context.active_object
            frond.scale = (0.2, 2, 0.1)
            bpy.ops.object.transform_apply(scale=True)
            frond.rotation_euler[2] = frond_angle
            frond.name = f"AI_palm_frond_{i}_{j}_1"
            oasis_objects.append(frond)
    
    return oasis_objects

def create_generic_water():
    """Create generic water feature"""
    water_objects = []
    
    bpy.ops.mesh.primitive_cylinder_add(
        radius=2,
        depth=0.3,
        location=(14.62359758822056, 22.101406494437892, -0.15)
    )
    water = bpy.context.active_object
    water.name = f"AI_water_generic_1"
    water_objects.append(water)
    
    return water_objects

# Execute water feature creation
try:
    created_water = create_water_feature()
    print(f"✅ Created water feature {'pond'} with {len(created_water)} components")
except Exception as e:
    print(f"❌ Error creating water feature: {e}")

print("💧 AI Water Feature Generation Complete!")
