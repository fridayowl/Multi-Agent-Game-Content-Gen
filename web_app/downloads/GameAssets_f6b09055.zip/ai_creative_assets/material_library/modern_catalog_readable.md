
# Modern Material Catalog

**Theme**: Modern  
**Total Materials**: 75  
**Generated**: 2025-06-19T14:41:46.911209

## Material Categories

### Buildings
*Building materials for modern architecture*
**Materials**: 18

- **Stone Wall - Modern Variant 1**
  - A modern stone wall material with unique properties
  - Metallic: -0.1, Roughness: 1.0

- **Stone Wall - Modern Variant 2**
  - A modern stone wall material with unique properties
  - Metallic: -0.1, Roughness: 1.0

- **Stone Wall - Modern Variant 3**
  - A modern stone wall material with unique properties
  - Metallic: 0.0, Roughness: 0.9

- **Wood Beam - Modern Variant 1**
  - A modern wood beam material with unique properties
  - Metallic: -0.1, Roughness: 1.0

- **Wood Beam - Modern Variant 2**
  - A modern wood beam material with unique properties
  - Metallic: -0.1, Roughness: 1.0

- **Wood Beam - Modern Variant 3**
  - A modern wood beam material with unique properties
  - Metallic: 0.0, Roughness: 1.0

- **Roof Tile - Modern Variant 1**
  - A modern roof tile material with unique properties
  - Metallic: -0.0, Roughness: 0.9

- **Roof Tile - Modern Variant 2**
  - A modern roof tile material with unique properties
  - Metallic: 0.1, Roughness: 0.8

- **Roof Tile - Modern Variant 3**
  - A modern roof tile material with unique properties
  - Metallic: -0.1, Roughness: 0.9

- **Door Wood - Modern Variant 1**
  - A modern door wood material with unique properties
  - Metallic: 0.1, Roughness: 0.9

- **Door Wood - Modern Variant 2**
  - A modern door wood material with unique properties
  - Metallic: 0.1, Roughness: 0.7

- **Door Wood - Modern Variant 3**
  - A modern door wood material with unique properties
  - Metallic: 0.0, Roughness: 0.8

- **Window Glass - Modern Variant 1**
  - A modern window glass material with unique properties
  - Metallic: 0.1, Roughness: 0.9

- **Window Glass - Modern Variant 2**
  - A modern window glass material with unique properties
  - Metallic: -0.0, Roughness: 0.7

- **Window Glass - Modern Variant 3**
  - A modern window glass material with unique properties
  - Metallic: 0.0, Roughness: 1.0

- **Foundation Stone - Modern Variant 1**
  - A modern foundation stone material with unique properties
  - Metallic: 0.0, Roughness: 0.9

- **Foundation Stone - Modern Variant 2**
  - A modern foundation stone material with unique properties
  - Metallic: 0.1, Roughness: 1.0

- **Foundation Stone - Modern Variant 3**
  - A modern foundation stone material with unique properties
  - Metallic: 0.0, Roughness: 0.7

### Natural
*Natural materials for modern environment*
**Materials**: 18

- **Tree Bark - Modern Variant 1**
  - A modern tree bark material with unique properties
  - Metallic: 0.1, Roughness: 0.7

- **Tree Bark - Modern Variant 2**
  - A modern tree bark material with unique properties
  - Metallic: 0.1, Roughness: 0.9

- **Tree Bark - Modern Variant 3**
  - A modern tree bark material with unique properties
  - Metallic: 0.1, Roughness: 0.7

- **Leaf Foliage - Modern Variant 1**
  - A modern leaf foliage material with unique properties
  - Metallic: 0.1, Roughness: 0.9

- **Leaf Foliage - Modern Variant 2**
  - A modern leaf foliage material with unique properties
  - Metallic: -0.0, Roughness: 1.0

- **Leaf Foliage - Modern Variant 3**
  - A modern leaf foliage material with unique properties
  - Metallic: 0.1, Roughness: 0.9

- **Grass Ground - Modern Variant 1**
  - A modern grass ground material with unique properties
  - Metallic: -0.0, Roughness: 1.0

- **Grass Ground - Modern Variant 2**
  - A modern grass ground material with unique properties
  - Metallic: -0.1, Roughness: 0.8

- **Grass Ground - Modern Variant 3**
  - A modern grass ground material with unique properties
  - Metallic: 0.1, Roughness: 0.8

- **Rock Surface - Modern Variant 1**
  - A modern rock surface material with unique properties
  - Metallic: 0.0, Roughness: 0.8

- **Rock Surface - Modern Variant 2**
  - A modern rock surface material with unique properties
  - Metallic: -0.0, Roughness: 0.8

- **Rock Surface - Modern Variant 3**
  - A modern rock surface material with unique properties
  - Metallic: -0.0, Roughness: 0.9

- **Dirt Path - Modern Variant 1**
  - A modern dirt path material with unique properties
  - Metallic: -0.0, Roughness: 0.9

- **Dirt Path - Modern Variant 2**
  - A modern dirt path material with unique properties
  - Metallic: -0.0, Roughness: 0.8

- **Dirt Path - Modern Variant 3**
  - A modern dirt path material with unique properties
  - Metallic: 0.1, Roughness: 0.9

- **Water Surface - Modern Variant 1**
  - A modern water surface material with unique properties
  - Metallic: -0.0, Roughness: 0.7

- **Water Surface - Modern Variant 2**
  - A modern water surface material with unique properties
  - Metallic: 0.1, Roughness: 0.7

- **Water Surface - Modern Variant 3**
  - A modern water surface material with unique properties
  - Metallic: -0.0, Roughness: 0.8

### Decorative
*Decorative materials for modern aesthetics*
**Materials**: 18

- **Fabric Banner - Modern Variant 1**
  - A modern fabric banner material with unique properties
  - Metallic: -0.1, Roughness: 0.7

- **Fabric Banner - Modern Variant 2**
  - A modern fabric banner material with unique properties
  - Metallic: 0.0, Roughness: 1.0

- **Fabric Banner - Modern Variant 3**
  - A modern fabric banner material with unique properties
  - Metallic: -0.0, Roughness: 0.8

- **Metal Accent - Modern Variant 1**
  - A modern metal accent material with unique properties
  - Metallic: 0.0, Roughness: 0.9

- **Metal Accent - Modern Variant 2**
  - A modern metal accent material with unique properties
  - Metallic: -0.1, Roughness: 0.8

- **Metal Accent - Modern Variant 3**
  - A modern metal accent material with unique properties
  - Metallic: 0.0, Roughness: 0.9

- **Carved Detail - Modern Variant 1**
  - A modern carved detail material with unique properties
  - Metallic: -0.0, Roughness: 0.8

- **Carved Detail - Modern Variant 2**
  - A modern carved detail material with unique properties
  - Metallic: -0.1, Roughness: 0.9

- **Carved Detail - Modern Variant 3**
  - A modern carved detail material with unique properties
  - Metallic: 0.0, Roughness: 1.0

- **Painted Surface - Modern Variant 1**
  - A modern painted surface material with unique properties
  - Metallic: -0.0, Roughness: 1.0

- **Painted Surface - Modern Variant 2**
  - A modern painted surface material with unique properties
  - Metallic: -0.0, Roughness: 0.8

- **Painted Surface - Modern Variant 3**
  - A modern painted surface material with unique properties
  - Metallic: 0.1, Roughness: 1.0

- **Crystal Gem - Modern Variant 1**
  - A modern crystal gem material with unique properties
  - Metallic: -0.0, Roughness: 1.0

- **Crystal Gem - Modern Variant 2**
  - A modern crystal gem material with unique properties
  - Metallic: -0.0, Roughness: 0.9

- **Crystal Gem - Modern Variant 3**
  - A modern crystal gem material with unique properties
  - Metallic: -0.0, Roughness: 0.7

- **Ornate Trim - Modern Variant 1**
  - A modern ornate trim material with unique properties
  - Metallic: 0.0, Roughness: 1.0

- **Ornate Trim - Modern Variant 2**
  - A modern ornate trim material with unique properties
  - Metallic: -0.1, Roughness: 1.0

- **Ornate Trim - Modern Variant 3**
  - A modern ornate trim material with unique properties
  - Metallic: -0.0, Roughness: 0.9

### Utility
*Utility materials for modern functionality*
**Materials**: 18

- **Rope Cord - Modern Variant 1**
  - A modern rope cord material with unique properties
  - Metallic: -0.1, Roughness: 0.9

- **Rope Cord - Modern Variant 2**
  - A modern rope cord material with unique properties
  - Metallic: -0.1, Roughness: 0.8

- **Rope Cord - Modern Variant 3**
  - A modern rope cord material with unique properties
  - Metallic: 0.1, Roughness: 0.7

- **Metal Tool - Modern Variant 1**
  - A modern metal tool material with unique properties
  - Metallic: 0.1, Roughness: 1.0

- **Metal Tool - Modern Variant 2**
  - A modern metal tool material with unique properties
  - Metallic: -0.1, Roughness: 0.8

- **Metal Tool - Modern Variant 3**
  - A modern metal tool material with unique properties
  - Metallic: -0.1, Roughness: 0.8

- **Leather Goods - Modern Variant 1**
  - A modern leather goods material with unique properties
  - Metallic: 0.0, Roughness: 0.8

- **Leather Goods - Modern Variant 2**
  - A modern leather goods material with unique properties
  - Metallic: -0.1, Roughness: 1.0

- **Leather Goods - Modern Variant 3**
  - A modern leather goods material with unique properties
  - Metallic: 0.0, Roughness: 0.8

- **Ceramic Pottery - Modern Variant 1**
  - A modern ceramic pottery material with unique properties
  - Metallic: 0.1, Roughness: 1.0

- **Ceramic Pottery - Modern Variant 2**
  - A modern ceramic pottery material with unique properties
  - Metallic: 0.0, Roughness: 0.9

- **Ceramic Pottery - Modern Variant 3**
  - A modern ceramic pottery material with unique properties
  - Metallic: -0.0, Roughness: 1.0

- **Cloth Covering - Modern Variant 1**
  - A modern cloth covering material with unique properties
  - Metallic: -0.0, Roughness: 1.0

- **Cloth Covering - Modern Variant 2**
  - A modern cloth covering material with unique properties
  - Metallic: 0.1, Roughness: 0.9

- **Cloth Covering - Modern Variant 3**
  - A modern cloth covering material with unique properties
  - Metallic: -0.0, Roughness: 0.7

- **Basket Weave - Modern Variant 1**
  - A modern basket weave material with unique properties
  - Metallic: -0.0, Roughness: 1.0

- **Basket Weave - Modern Variant 2**
  - A modern basket weave material with unique properties
  - Metallic: 0.1, Roughness: 0.8

- **Basket Weave - Modern Variant 3**
  - A modern basket weave material with unique properties
  - Metallic: 0.1, Roughness: 1.0

### Special
*Special materials unique to modern theme*
**Materials**: 3

- **Generic Special - Modern Variant 1**
  - A modern generic special material with unique properties
  - Metallic: 0.0, Roughness: 0.9

- **Generic Special - Modern Variant 2**
  - A modern generic special material with unique properties
  - Metallic: 0.1, Roughness: 1.0

- **Generic Special - Modern Variant 3**
  - A modern generic special material with unique properties
  - Metallic: -0.0, Roughness: 1.0


## Usage Guidelines

1. **Building Materials**: Use for structural elements and architecture
2. **Natural Materials**: Apply to terrain and vegetation
3. **Decorative Materials**: Add visual interest and detail
4. **Utility Materials**: Functional elements and props
5. **Special Materials**: Theme-specific unique elements

## Export Formats

All materials are available in the following formats:
- Blender (.blend)
- Unity (.mat)
- Godot (.tres)
- glTF (.json)

---
*Generated by AI Creative Asset Generator - Modular Version*
