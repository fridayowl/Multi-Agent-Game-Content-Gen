
# Spooky Material Catalog

**Theme**: Spooky  
**Total Materials**: 84  
**Generated**: 2025-06-19T14:51:45.636415

## Material Categories

### Buildings
*Building materials for spooky architecture*
**Materials**: 18

- **Stone Wall - Spooky Variant 1**
  - A spooky stone wall material with unique properties
  - Metallic: -0.0, Roughness: 0.9

- **Stone Wall - Spooky Variant 2**
  - A spooky stone wall material with unique properties
  - Metallic: 0.1, Roughness: 0.8

- **Stone Wall - Spooky Variant 3**
  - A spooky stone wall material with unique properties
  - Metallic: -0.0, Roughness: 0.9

- **Wood Beam - Spooky Variant 1**
  - A spooky wood beam material with unique properties
  - Metallic: 0.1, Roughness: 1.0

- **Wood Beam - Spooky Variant 2**
  - A spooky wood beam material with unique properties
  - Metallic: 0.0, Roughness: 0.8

- **Wood Beam - Spooky Variant 3**
  - A spooky wood beam material with unique properties
  - Metallic: -0.1, Roughness: 0.8

- **Roof Tile - Spooky Variant 1**
  - A spooky roof tile material with unique properties
  - Metallic: -0.0, Roughness: 1.0

- **Roof Tile - Spooky Variant 2**
  - A spooky roof tile material with unique properties
  - Metallic: 0.1, Roughness: 1.0

- **Roof Tile - Spooky Variant 3**
  - A spooky roof tile material with unique properties
  - Metallic: -0.1, Roughness: 0.8

- **Door Wood - Spooky Variant 1**
  - A spooky door wood material with unique properties
  - Metallic: 0.1, Roughness: 0.7

- **Door Wood - Spooky Variant 2**
  - A spooky door wood material with unique properties
  - Metallic: 0.1, Roughness: 0.9

- **Door Wood - Spooky Variant 3**
  - A spooky door wood material with unique properties
  - Metallic: 0.1, Roughness: 1.0

- **Window Glass - Spooky Variant 1**
  - A spooky window glass material with unique properties
  - Metallic: -0.0, Roughness: 0.8

- **Window Glass - Spooky Variant 2**
  - A spooky window glass material with unique properties
  - Metallic: -0.0, Roughness: 0.9

- **Window Glass - Spooky Variant 3**
  - A spooky window glass material with unique properties
  - Metallic: 0.1, Roughness: 0.8

- **Foundation Stone - Spooky Variant 1**
  - A spooky foundation stone material with unique properties
  - Metallic: 0.0, Roughness: 1.0

- **Foundation Stone - Spooky Variant 2**
  - A spooky foundation stone material with unique properties
  - Metallic: -0.0, Roughness: 0.7

- **Foundation Stone - Spooky Variant 3**
  - A spooky foundation stone material with unique properties
  - Metallic: -0.1, Roughness: 0.7

### Natural
*Natural materials for spooky environment*
**Materials**: 18

- **Tree Bark - Spooky Variant 1**
  - A spooky tree bark material with unique properties
  - Metallic: 0.0, Roughness: 1.0

- **Tree Bark - Spooky Variant 2**
  - A spooky tree bark material with unique properties
  - Metallic: -0.1, Roughness: 1.0

- **Tree Bark - Spooky Variant 3**
  - A spooky tree bark material with unique properties
  - Metallic: -0.1, Roughness: 1.0

- **Leaf Foliage - Spooky Variant 1**
  - A spooky leaf foliage material with unique properties
  - Metallic: -0.1, Roughness: 1.0

- **Leaf Foliage - Spooky Variant 2**
  - A spooky leaf foliage material with unique properties
  - Metallic: -0.1, Roughness: 0.8

- **Leaf Foliage - Spooky Variant 3**
  - A spooky leaf foliage material with unique properties
  - Metallic: -0.1, Roughness: 1.0

- **Grass Ground - Spooky Variant 1**
  - A spooky grass ground material with unique properties
  - Metallic: -0.0, Roughness: 0.8

- **Grass Ground - Spooky Variant 2**
  - A spooky grass ground material with unique properties
  - Metallic: -0.0, Roughness: 0.9

- **Grass Ground - Spooky Variant 3**
  - A spooky grass ground material with unique properties
  - Metallic: -0.0, Roughness: 0.7

- **Rock Surface - Spooky Variant 1**
  - A spooky rock surface material with unique properties
  - Metallic: 0.0, Roughness: 1.0

- **Rock Surface - Spooky Variant 2**
  - A spooky rock surface material with unique properties
  - Metallic: 0.0, Roughness: 0.8

- **Rock Surface - Spooky Variant 3**
  - A spooky rock surface material with unique properties
  - Metallic: 0.0, Roughness: 0.8

- **Dirt Path - Spooky Variant 1**
  - A spooky dirt path material with unique properties
  - Metallic: 0.0, Roughness: 1.0

- **Dirt Path - Spooky Variant 2**
  - A spooky dirt path material with unique properties
  - Metallic: 0.0, Roughness: 0.8

- **Dirt Path - Spooky Variant 3**
  - A spooky dirt path material with unique properties
  - Metallic: -0.1, Roughness: 1.0

- **Water Surface - Spooky Variant 1**
  - A spooky water surface material with unique properties
  - Metallic: 0.0, Roughness: 0.8

- **Water Surface - Spooky Variant 2**
  - A spooky water surface material with unique properties
  - Metallic: -0.0, Roughness: 1.0

- **Water Surface - Spooky Variant 3**
  - A spooky water surface material with unique properties
  - Metallic: -0.1, Roughness: 0.8

### Decorative
*Decorative materials for spooky aesthetics*
**Materials**: 18

- **Fabric Banner - Spooky Variant 1**
  - A spooky fabric banner material with unique properties
  - Metallic: -0.1, Roughness: 0.8

- **Fabric Banner - Spooky Variant 2**
  - A spooky fabric banner material with unique properties
  - Metallic: -0.1, Roughness: 0.7

- **Fabric Banner - Spooky Variant 3**
  - A spooky fabric banner material with unique properties
  - Metallic: -0.1, Roughness: 1.0

- **Metal Accent - Spooky Variant 1**
  - A spooky metal accent material with unique properties
  - Metallic: 0.1, Roughness: 0.9

- **Metal Accent - Spooky Variant 2**
  - A spooky metal accent material with unique properties
  - Metallic: -0.1, Roughness: 0.7

- **Metal Accent - Spooky Variant 3**
  - A spooky metal accent material with unique properties
  - Metallic: -0.0, Roughness: 1.0

- **Carved Detail - Spooky Variant 1**
  - A spooky carved detail material with unique properties
  - Metallic: 0.0, Roughness: 0.7

- **Carved Detail - Spooky Variant 2**
  - A spooky carved detail material with unique properties
  - Metallic: -0.0, Roughness: 0.8

- **Carved Detail - Spooky Variant 3**
  - A spooky carved detail material with unique properties
  - Metallic: 0.0, Roughness: 0.8

- **Painted Surface - Spooky Variant 1**
  - A spooky painted surface material with unique properties
  - Metallic: 0.0, Roughness: 1.0

- **Painted Surface - Spooky Variant 2**
  - A spooky painted surface material with unique properties
  - Metallic: 0.1, Roughness: 0.8

- **Painted Surface - Spooky Variant 3**
  - A spooky painted surface material with unique properties
  - Metallic: 0.1, Roughness: 1.0

- **Crystal Gem - Spooky Variant 1**
  - A spooky crystal gem material with unique properties
  - Metallic: -0.0, Roughness: 0.9

- **Crystal Gem - Spooky Variant 2**
  - A spooky crystal gem material with unique properties
  - Metallic: -0.1, Roughness: 1.0

- **Crystal Gem - Spooky Variant 3**
  - A spooky crystal gem material with unique properties
  - Metallic: 0.0, Roughness: 1.0

- **Ornate Trim - Spooky Variant 1**
  - A spooky ornate trim material with unique properties
  - Metallic: 0.0, Roughness: 0.8

- **Ornate Trim - Spooky Variant 2**
  - A spooky ornate trim material with unique properties
  - Metallic: 0.1, Roughness: 1.0

- **Ornate Trim - Spooky Variant 3**
  - A spooky ornate trim material with unique properties
  - Metallic: 0.1, Roughness: 0.9

### Utility
*Utility materials for spooky functionality*
**Materials**: 18

- **Rope Cord - Spooky Variant 1**
  - A spooky rope cord material with unique properties
  - Metallic: 0.0, Roughness: 0.8

- **Rope Cord - Spooky Variant 2**
  - A spooky rope cord material with unique properties
  - Metallic: -0.1, Roughness: 0.8

- **Rope Cord - Spooky Variant 3**
  - A spooky rope cord material with unique properties
  - Metallic: -0.1, Roughness: 0.9

- **Metal Tool - Spooky Variant 1**
  - A spooky metal tool material with unique properties
  - Metallic: -0.1, Roughness: 1.0

- **Metal Tool - Spooky Variant 2**
  - A spooky metal tool material with unique properties
  - Metallic: -0.1, Roughness: 0.8

- **Metal Tool - Spooky Variant 3**
  - A spooky metal tool material with unique properties
  - Metallic: -0.1, Roughness: 0.9

- **Leather Goods - Spooky Variant 1**
  - A spooky leather goods material with unique properties
  - Metallic: 0.0, Roughness: 0.9

- **Leather Goods - Spooky Variant 2**
  - A spooky leather goods material with unique properties
  - Metallic: 0.1, Roughness: 1.0

- **Leather Goods - Spooky Variant 3**
  - A spooky leather goods material with unique properties
  - Metallic: 0.0, Roughness: 0.8

- **Ceramic Pottery - Spooky Variant 1**
  - A spooky ceramic pottery material with unique properties
  - Metallic: 0.0, Roughness: 0.9

- **Ceramic Pottery - Spooky Variant 2**
  - A spooky ceramic pottery material with unique properties
  - Metallic: 0.1, Roughness: 1.0

- **Ceramic Pottery - Spooky Variant 3**
  - A spooky ceramic pottery material with unique properties
  - Metallic: 0.1, Roughness: 0.7

- **Cloth Covering - Spooky Variant 1**
  - A spooky cloth covering material with unique properties
  - Metallic: 0.0, Roughness: 1.0

- **Cloth Covering - Spooky Variant 2**
  - A spooky cloth covering material with unique properties
  - Metallic: 0.1, Roughness: 0.9

- **Cloth Covering - Spooky Variant 3**
  - A spooky cloth covering material with unique properties
  - Metallic: 0.0, Roughness: 1.0

- **Basket Weave - Spooky Variant 1**
  - A spooky basket weave material with unique properties
  - Metallic: -0.0, Roughness: 0.9

- **Basket Weave - Spooky Variant 2**
  - A spooky basket weave material with unique properties
  - Metallic: -0.0, Roughness: 1.0

- **Basket Weave - Spooky Variant 3**
  - A spooky basket weave material with unique properties
  - Metallic: 0.1, Roughness: 0.8

### Special
*Special materials unique to spooky theme*
**Materials**: 12

- **Weathered Bone - Spooky Variant 1**
  - A spooky weathered bone material with unique properties
  - Metallic: 0.0, Roughness: 0.7

- **Weathered Bone - Spooky Variant 2**
  - A spooky weathered bone material with unique properties
  - Metallic: 0.0, Roughness: 0.9

- **Weathered Bone - Spooky Variant 3**
  - A spooky weathered bone material with unique properties
  - Metallic: -0.0, Roughness: 0.9

- **Tattered Cloth - Spooky Variant 1**
  - A spooky tattered cloth material with unique properties
  - Metallic: -0.1, Roughness: 0.9

- **Tattered Cloth - Spooky Variant 2**
  - A spooky tattered cloth material with unique properties
  - Metallic: -0.0, Roughness: 0.7

- **Tattered Cloth - Spooky Variant 3**
  - A spooky tattered cloth material with unique properties
  - Metallic: -0.0, Roughness: 1.0

- **Rusted Metal - Spooky Variant 1**
  - A spooky rusted metal material with unique properties
  - Metallic: -0.0, Roughness: 0.9

- **Rusted Metal - Spooky Variant 2**
  - A spooky rusted metal material with unique properties
  - Metallic: 0.0, Roughness: 0.8

- **Rusted Metal - Spooky Variant 3**
  - A spooky rusted metal material with unique properties
  - Metallic: 0.1, Roughness: 0.9

- **Eerie Glow - Spooky Variant 1**
  - A spooky eerie glow material with unique properties
  - Metallic: 0.1, Roughness: 1.0

- **Eerie Glow - Spooky Variant 2**
  - A spooky eerie glow material with unique properties
  - Metallic: -0.0, Roughness: 1.0

- **Eerie Glow - Spooky Variant 3**
  - A spooky eerie glow material with unique properties
  - Metallic: 0.0, Roughness: 0.8


## Usage Guidelines

1. **Building Materials**: Use for structural elements and architecture
2. **Natural Materials**: Apply to terrain and vegetation
3. **Decorative Materials**: Add visual interest and detail
4. **Utility Materials**: Functional elements and props
5. **Special Materials**: Theme-specific unique elements

## Export Formats

All materials are available in the following formats:
- Blender (.blend)
- Unity (.mat)
- Godot (.tres)
- glTF (.json)

---
*Generated by AI Creative Asset Generator - Modular Version*
