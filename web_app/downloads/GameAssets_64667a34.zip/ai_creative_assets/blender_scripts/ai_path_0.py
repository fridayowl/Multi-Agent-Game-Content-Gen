
import bpy
import bmesh
from mathutils import Vector

# AI-GENERATED PATH
# Path 0 in spooky theme
# Points: 3

def create_ai_path():
    """Create AI-designed path"""
    path_objects = []
    
    # Path parameters
    path_width = 2.0
    path_segments = 2
    
    # Create path curve
    curve_data = bpy.data.curves.new(name=f"AI_Path_0", type='CURVE')
    curve_data.dimensions = '3D'
    
    # Create spline
    spline = curve_data.splines.new('BEZIER')
    spline.bezier_points.add(path_segments)
    
    # Set path points
    points = [{'x': 14.000000000000002, 'y': 30.392304845413264, 'z': 0.0}, {'x': 23.330395849047985, 'y': 25.526548271754617, 'z': 0}, {'x': 32.0, 'y': 20.0, 'z': 0.0}]
    for i, point in enumerate(points):
        bezier_point = spline.bezier_points[i]
        bezier_point.co = (point['x'], point['y'], point.get('z', 0))
        bezier_point.handle_left_type = 'AUTO'
        bezier_point.handle_right_type = 'AUTO'
    
    # Create curve object
    curve_obj = bpy.data.objects.new(f"AI_Path_Curve_0", curve_data)
    bpy.context.collection.objects.link(curve_obj)
    
    # Convert to mesh and extrude for path width
    bpy.context.view_layer.objects.active = curve_obj
    bpy.ops.object.convert(target='MESH')
    
    path_mesh = bpy.context.active_object
    path_mesh.name = f"AI_Path_0"
    
    return [path_mesh]

# Execute path creation
try:
    created_path = create_ai_path()
    print(f"✅ Created AI path with {len(created_path)} components")
except Exception as e:
    print(f"❌ Error creating path: {e}")

print("🛤️ AI Path Generation Complete!")
