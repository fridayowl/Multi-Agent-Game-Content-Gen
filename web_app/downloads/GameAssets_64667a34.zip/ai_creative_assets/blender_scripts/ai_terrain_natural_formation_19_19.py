
import bpy
import random
import math

# AI-GENERATED TERRAIN FEATURE
# Feature: natural_formation
# Theme: spooky
# Position: (19.6, 19.4)

def create_terrain_feature():
    """Create natural_formation terrain feature"""
    feature_objects = []
    
    if "natural_formation" == "clearing":
        # Create a natural clearing
        clearing = create_clearing()
        feature_objects.extend(clearing)
    elif "natural_formation" == "rocky_outcrop":
        # Create rocky formation
        rocks = create_rocky_outcrop()
        feature_objects.extend(rocks)
    elif "natural_formation" == "flower_field":
        # Create flower field
        flowers = create_flower_field()
        feature_objects.extend(flowers)
    else:
        # Generic natural formation
        formation = create_generic_formation()
        feature_objects.extend(formation)
    
    return feature_objects

def create_clearing():
    """Create a natural clearing"""
    clearing_objects = []
    
    # Create clearing ground
    bpy.ops.mesh.primitive_cylinder_add(
        radius=8,
        depth=0.1,
        location=(19.599613152804643, 19.438104448742745, 0.05)
    )
    ground = bpy.context.active_object
    ground.name = "AI_clearing_ground"
    clearing_objects.append(ground)
    
    # Add scattered logs or stones around edge
    for i in range(random.randint(3, 6)):
        angle = i * (2 * math.pi / 6) + random.uniform(-0.5, 0.5)
        radius = random.uniform(6, 9)
        log_x = 19.599613152804643 + math.cos(angle) * radius
        log_y = 19.438104448742745 + math.sin(angle) * radius
        
        bpy.ops.mesh.primitive_cylinder_add(
            radius=0.3,
            depth=2,
            location=(log_x, log_y, 0.15)
        )
        log = bpy.context.active_object
        log.rotation_euler[1] = math.radians(90)  # Lay log horizontally
        log.rotation_euler[2] = angle
        log.name = f"AI_clearing_log_{i}"
        clearing_objects.append(log)
    
    return clearing_objects

def create_rocky_outcrop():
    """Create rocky outcrop formation"""
    rock_objects = []
    
    # Create main rock formation
    for i in range(random.randint(3, 7)):
        rock_size = random.uniform(1, 3)
        offset_x = random.uniform(-4, 4)
        offset_y = random.uniform(-4, 4)
        height = random.uniform(0.5, 2.5)
        
        bpy.ops.mesh.primitive_ico_sphere_add(
            subdivisions=1,
            radius=rock_size,
            location=(19.599613152804643 + offset_x, 19.438104448742745 + offset_y, height)
        )
        rock = bpy.context.active_object
        rock.scale = (1, 1, random.uniform(0.6, 1.4))  # Vary height
        bpy.ops.object.transform_apply(scale=True)
        rock.name = f"AI_outcrop_rock_{i}"
        rock_objects.append(rock)
    
    return rock_objects

def create_flower_field():
    """Create a field of flowers"""
    flower_objects = []
    
    # Create flower clusters
    for i in range(random.randint(15, 25)):
        cluster_x = 19.599613152804643 + random.uniform(-10, 10)
        cluster_y = 19.438104448742745 + random.uniform(-10, 10)
        
        # Create flower cluster as small spheres
        bpy.ops.mesh.primitive_ico_sphere_add(
            subdivisions=1,
            radius=0.2,
            location=(cluster_x, cluster_y, 0.3)
        )
        flower = bpy.context.active_object
        
        # Random flower colors
        if random.random() < 0.5:
            flower.color = (random.uniform(0.8, 1), random.uniform(0.6, 0.9), random.uniform(0.6, 0.9), 1)
        else:
            flower.color = (random.uniform(0.9, 1), random.uniform(0.8, 1), random.uniform(0.4, 0.7), 1)
        
        flower.name = f"AI_flower_{i}"
        flower_objects.append(flower)
    
    return flower_objects

def create_generic_formation():
    """Create generic natural formation"""
    formation_objects = []
    
    # Create central feature
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=2,
        radius=2,
        location=(19.599613152804643, 19.438104448742745, 1)
    )
    center = bpy.context.active_object
    center.name = "AI_formation_center"
    formation_objects.append(center)
    
    return formation_objects

# Execute terrain feature creation
try:
    created_feature = create_terrain_feature()
    print(f"✅ Created terrain feature {'natural_formation'} with {len(created_feature)} components")
except Exception as e:
    print(f"❌ Error creating terrain feature: {e}")

print("🌍 AI Terrain Feature Generation Complete!")
