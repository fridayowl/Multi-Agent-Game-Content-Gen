
import bpy
import bmesh
import random
import math
from mathutils import Vector

# AI-GENERATED CREATIVE BUILDING
# Building #3: tower
# AI Description: A unique spooky tower with architectural details
# Style Parameters: {'roof_type': 'flat', 'wall_material': 'timber_frame', 'foundation': 'raised', 'window_style': 'double_hung', 'door_style': 'arched', 'chimney': 'double', 'stories': 1, 'architectural_style': 'colonial', 'condition': 'haunted', 'special_features': 'overgrown'}
# Architectural Details: {'dimensions': {'width': 18.154801698801265, 'length': 12.582285708997958, 'height': 12.705034036421308}, 'structural_elements': {'support_beams': True, 'load_bearing_walls': True, 'foundation_depth': 3.0242275188327272}, 'roof_details': {'type': 'flat', 'pitch': 0, 'material': 'thatch', 'overhang': 0.6949271978867955}, 'openings': {'window_count': 2, 'door_count': 1, 'window_size': 'medium', 'door_width': 1.0748397807135293, 'window_placement': 'grouped'}, 'atmospheric_elements': {'weathering': 'severe', 'overgrowth': False, 'mysterious_features': 'strange_sounds'}}

# Clear scene
bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete(use_global=False, confirm=False)

# AI Texture paths
ai_textures = {"walls": "textures/buildings/stone_spooky_49f86107.png", "roof": "textures/buildings/wood_spooky_4df2a152.png", "foundation": "textures/buildings/stone_spooky_afe2950a.png"}

# Building Parameters
BUILDING_WIDTH = 18.154801698801265
BUILDING_LENGTH = 12.582285708997958
BUILDING_HEIGHT = 12.705034036421308
STORIES = 1
ROOF_TYPE = "flat"
WALL_MATERIAL = "timber_frame"

# Position
POS_X = 13.999999999999995
POS_Y = 9.60769515458674
POS_Z = 0.0

print(f"🏗️ Creating AI-Designed tower:")
print(f"   📐 Dimensions: {BUILDING_WIDTH:.1f} x {BUILDING_LENGTH:.1f} x {BUILDING_HEIGHT:.1f}")
print(f"   🏠 Stories: {STORIES}")
print(f"   🏠 Roof: {ROOF_TYPE}")
print(f"   🧱 Material: {WALL_MATERIAL}")

def create_ai_building():
    """Create complete AI-designed building"""
    building_objects = []
    
    # Create foundation
    foundation = create_foundation()
    if foundation:
        building_objects.append(foundation)
    
    # Create walls for each story
    for story in range(STORIES):
        story_height = BUILDING_HEIGHT / STORIES
        story_walls = create_story_walls(story, story_height)
        building_objects.extend(story_walls)
    
    # Create roof
    roof = create_roof()
    if roof:
        building_objects.append(roof)
    
    # Add architectural details
    details = create_architectural_details()
    building_objects.extend(details)
    
    # Join all building components
    if len(building_objects) > 1:
        bpy.ops.object.select_all(action='DESELECT')
        for obj in building_objects:
            if obj and obj.name in bpy.data.objects:
                obj.select_set(True)
        
        if building_objects:
            bpy.context.view_layer.objects.active = building_objects[0]
            bpy.ops.object.join()
            
            final_building = bpy.context.active_object
            final_building.name = f"AI_tower_2"
            final_building.location = (POS_X, POS_Y, POS_Z)
            
            print(f"✅ Created AI tower with {len(building_objects)} components")
    
    return building_objects

def create_foundation():
    """Create building foundation"""
    foundation_height = 0.5
    
    bpy.ops.mesh.primitive_cube_add(
        size=1,
        location=(0, 0, foundation_height/2)
    )
    foundation = bpy.context.active_object
    foundation.scale = (BUILDING_WIDTH, BUILDING_LENGTH, foundation_height)
    bpy.ops.object.transform_apply(scale=True)
    foundation.name = f"AI_foundation_2"
    
    return foundation

def create_story_walls(story_number: int, story_height: float):
    """Create walls for a specific story"""
    story_objects = []
    base_z = 0.5 + (story_number * story_height)  # Account for foundation
    
    # Wall thickness
    wall_thickness = 0.3
    
    # Create four walls
    walls_data = [
        {'name': 'front', 'size': (BUILDING_WIDTH, wall_thickness, story_height), 
          'pos': (0, -BUILDING_LENGTH/2 + wall_thickness/2, base_z + story_height/2)},
        {'name': 'back', 'size': (BUILDING_WIDTH, wall_thickness, story_height),
          'pos': (0, BUILDING_LENGTH/2 - wall_thickness/2, base_z + story_height/2)},
        {'name': 'left', 'size': (wall_thickness, BUILDING_LENGTH - wall_thickness, story_height),
          'pos': (-BUILDING_WIDTH/2 + wall_thickness/2, 0, base_z + story_height/2)},
        {'name': 'right', 'size': (wall_thickness, BUILDING_LENGTH - wall_thickness, story_height),
          'pos': (BUILDING_WIDTH/2 - wall_thickness/2, 0, base_z + story_height/2)}
    ]
    
    for wall_data in walls_data:
        bpy.ops.mesh.primitive_cube_add(
            size=1,
            location=wall_data['pos']
        )
        wall = bpy.context.active_object
        wall.scale = wall_data['size']
        bpy.ops.object.transform_apply(scale=True)
        wall.name = f"AI_wall_{wall_data['name']}_story{story_number}_2"
        story_objects.append(wall)
    
    # Add windows and doors for ground floor
    if story_number == 0:
        openings = create_openings(base_z, story_height)
        story_objects.extend(openings)
    
    return story_objects

def create_roof():
    """Create building roof based on roof type"""
    roof_base_z = 0.5 + (STORIES * (BUILDING_HEIGHT / STORIES))
    
    if ROOF_TYPE == "gabled":
        return create_gabled_roof(roof_base_z)
    elif ROOF_TYPE == "hipped":
        return create_hipped_roof(roof_base_z)
    elif ROOF_TYPE == "flat":
        return create_flat_roof(roof_base_z)
    else:
        return create_gabled_roof(roof_base_z)  # Default

def create_gabled_roof(base_z: float):
    """Create a gabled roof"""
    roof_height = 0.0  # Convert pitch to height factor
    roof_peak_height = roof_height * (BUILDING_WIDTH / 2)
    
    # Create roof as a triangular prism
    bpy.ops.mesh.primitive_cube_add(
        size=1,
        location=(0, 0, base_z + roof_peak_height/2)
    )
    roof = bpy.context.active_object
    roof.scale = (BUILDING_WIDTH + 1, BUILDING_LENGTH + 1, roof_peak_height)
    bpy.ops.object.transform_apply(scale=True)
    
    # Convert to mesh and create gabled shape
    bpy.context.view_layer.objects.active = roof
    bpy.ops.object.mode_set(mode='EDIT')
    
    # Select top face and extrude to create peak
    bpy.ops.mesh.select_all(action='DESELECT')
    bpy.ops.mesh.select_face_by_sides(number=4, type='EQUAL')
    bpy.ops.mesh.inset_faces(thickness=BUILDING_WIDTH/4)
    bpy.ops.mesh.extrude_region_move(
        TRANSFORM_OT_translate={"value": (0, 0, roof_peak_height/2)}
    )
    
    bpy.ops.object.mode_set(mode='OBJECT')
    roof.name = f"AI_gabled_roof_2"
    
    return roof

def create_hipped_roof(base_z: float):
    """Create a hipped roof"""
    roof_height = 0.0
    roof_peak_height = roof_height * min(BUILDING_WIDTH, BUILDING_LENGTH) / 2
    
    bpy.ops.mesh.primitive_cube_add(
        size=1,
        location=(0, 0, base_z + roof_peak_height/2)
    )
    roof = bpy.context.active_object
    roof.scale = (BUILDING_WIDTH + 1, BUILDING_LENGTH + 1, roof_peak_height)
    bpy.ops.object.transform_apply(scale=True)
    roof.name = f"AI_hipped_roof_2"
    
    return roof

def create_flat_roof(base_z: float):
    """Create a flat roof"""
    roof_thickness = 0.3
    
    bpy.ops.mesh.primitive_cube_add(
        size=1,
        location=(0, 0, base_z + roof_thickness/2)
    )
    roof = bpy.context.active_object
    roof.scale = (BUILDING_WIDTH + 0.5, BUILDING_LENGTH + 0.5, roof_thickness)
    bpy.ops.object.transform_apply(scale=True)
    roof.name = f"AI_flat_roof_2"
    
    return roof

def create_openings(base_z: float, story_height: float):
    """Create windows and doors"""
    openings = []
    
    # Create main door
    door_width = 1.0
    door_height = 2.0
    door_depth = 0.1
    
    bpy.ops.mesh.primitive_cube_add(
        size=1,
        location=(0, -BUILDING_LENGTH/2 - door_depth/2, base_z + door_height/2)
    )
    door = bpy.context.active_object
    door.scale = (door_width, door_depth, door_height)
    bpy.ops.object.transform_apply(scale=True)
    door.name = f"AI_door_2"
    openings.append(door)
    
    # Create windows
    window_count = 2
    window_size = 0.8
    window_height = 1.2
    window_depth = 0.05
    
    for i in range(window_count):
        # Distribute windows around the building
        if i < 2:  # Front wall windows
            x_pos = (-BUILDING_WIDTH/3) + (i * (2*BUILDING_WIDTH/3))
            y_pos = -BUILDING_LENGTH/2 - window_depth/2
        else:  # Side wall windows
            side = i - 2
            x_pos = (-BUILDING_WIDTH/2 - window_depth/2) if side == 0 else (BUILDING_WIDTH/2 + window_depth/2)
            y_pos = (-BUILDING_LENGTH/4) + (side * (BUILDING_LENGTH/2))
        
        bpy.ops.mesh.primitive_cube_add(
            size=1,
            location=(x_pos, y_pos, base_z + story_height * 0.6)
        )
        window = bpy.context.active_object
        window.scale = (window_size, window_depth, window_height)
        bpy.ops.object.transform_apply(scale=True)
        window.name = f"AI_window_{i}_2"
        openings.append(window)
    
    return openings

def create_architectural_details():
    """Create building-specific architectural details"""
    details = []
    
    # Add chimney if specified
    chimney_type = "double"
    if chimney_type != "none":
        chimney = create_chimney()
        if chimney:
            details.append(chimney)
    
    # Add building-type specific details
    if "tower" == "tavern":
        # Add tavern sign
        sign = create_tavern_sign()
        if sign:
            details.append(sign)
    elif "tower" == "church":
        # Add cross or religious symbol
        symbol = create_religious_symbol()
        if symbol:
            details.append(symbol)
    elif "tower" == "shop":
        # Add shop awning
        awning = create_shop_awning()
        if awning:
            details.append(awning)
    
    return details

def create_chimney():
    """Create a chimney"""
    chimney_width = 0.8
    chimney_height = 2.5
    roof_top_z = 0.5 + (STORIES * (BUILDING_HEIGHT / STORIES)) + 1.0  # Approximate roof height
    
    bpy.ops.mesh.primitive_cube_add(
        size=1,
        location=(BUILDING_WIDTH/3, BUILDING_LENGTH/3, roof_top_z + chimney_height/2)
    )
    chimney = bpy.context.active_object
    chimney.scale = (chimney_width, chimney_width, chimney_height)
    bpy.ops.object.transform_apply(scale=True)
    chimney.name = f"AI_chimney_2"
    
    return chimney

def create_tavern_sign():
    """Create a tavern sign"""
    sign_post_height = 3.0
    sign_width = 1.5
    sign_height = 0.8
    
    # Sign post
    bpy.ops.mesh.primitive_cylinder_add(
        radius=0.05,
        depth=sign_post_height,
        location=(BUILDING_WIDTH/2 + 1, -BUILDING_LENGTH/2 - 0.5, sign_post_height/2)
    )
    post = bpy.context.active_object
    post.name = f"AI_sign_post_2"
    
    # Sign board
    bpy.ops.mesh.primitive_cube_add(
        size=1,
        location=(BUILDING_WIDTH/2 + 1, -BUILDING_LENGTH/2 - 0.5, sign_post_height * 0.7)
    )
    sign = bpy.context.active_object
    sign.scale = (sign_width, 0.1, sign_height)
    bpy.ops.object.transform_apply(scale=True)
    sign.name = f"AI_sign_board_2"
    
    return post  # Return one object, they'll be joined later

def create_religious_symbol():
    """Create a religious symbol for church"""
    symbol_height = 1.5
    roof_top_z = 0.5 + (STORIES * (BUILDING_HEIGHT / STORIES)) + 1.5
    
    # Simple cross
    bpy.ops.mesh.primitive_cube_add(
        size=1,
        location=(0, 0, roof_top_z + symbol_height/2)
    )
    cross_vertical = bpy.context.active_object
    cross_vertical.scale = (0.1, 0.1, symbol_height)
    bpy.ops.object.transform_apply(scale=True)
    cross_vertical.name = f"AI_cross_vertical_2"
    
    bpy.ops.mesh.primitive_cube_add(
        size=1,
        location=(0, 0, roof_top_z + symbol_height * 0.7)
    )
    cross_horizontal = bpy.context.active_object
    cross_horizontal.scale = (0.6, 0.1, 0.1)
    bpy.ops.object.transform_apply(scale=True)
    cross_horizontal.name = f"AI_cross_horizontal_2"
    
    return cross_vertical

def create_shop_awning():
    """Create a shop awning"""
    awning_width = BUILDING_WIDTH * 0.8
    awning_depth = 1.0
    awning_height = 0.1
    
    bpy.ops.mesh.primitive_cube_add(
        size=1,
        location=(0, -BUILDING_LENGTH/2 - awning_depth/2, (BUILDING_HEIGHT / STORIES) * 0.8)
    )
    awning = bpy.context.active_object
    awning.scale = (awning_width, awning_depth, awning_height)
    bpy.ops.object.transform_apply(scale=True)
    awning.name = f"AI_awning_2"
    
    return awning

# Execute the building creation
try:
    created_objects = create_ai_building()
    print(f"✅ Successfully created AI tower with {len(created_objects)} components")
    print(f"🏗️ Architectural Style: {'roof_type': 'flat', 'wall_material': 'timber_frame', 'foundation': 'raised', 'window_style': 'double_hung', 'door_style': 'arched', 'chimney': 'double', 'stories': 1, 'architectural_style': 'colonial', 'condition': 'haunted', 'special_features': 'overgrown'}")
    print(f"📐 Dimensions: {BUILDING_WIDTH} x {BUILDING_LENGTH} x {BUILDING_HEIGHT}")
    print(f"🎯 Variations: 2")
except Exception as e:
    print(f"❌ Error creating AI tower: {e}")
    import traceback
    traceback.print_exc()

print("🏗️ AI-Creative Building Generation Script Complete!")
